
#ifndef CONFIG_H
#define CONFIG_H

#define _XTAL_FREQ 20000000

#endif
