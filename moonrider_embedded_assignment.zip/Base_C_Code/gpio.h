
#ifndef GPIO_H
#define GPIO_H

void init_gpio(void);
void handle_buttons(void);
void handle_indicators(void);

#endif
