
#include <xc.h>
#include "config.h"
#include "uart.h"
#include "gpio.h"
#include "timer.h"

void main(void) {
    init_gpio();
    init_uart();
    init_timer();

    while (1) {
        handle_buttons();
        handle_indicators();
        log_status();
    }
}
