
#include <xc.h>
#include "timer.h"

void init_timer(void) {
    T0CON = 0x87; // Timer0 ON, prescaler 256
}
