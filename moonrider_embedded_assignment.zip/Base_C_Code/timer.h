
#ifndef TIMER_H
#define TIMER_H

void init_timer(void);

#endif
