
#include <xc.h>
#include "uart.h"

void init_uart(void) {
    TXSTAbits.BRGH = 1;
    BAUDCTLbits.BRG16 = 1;
    SPBRG = 129; // 9600 baud rate
    RCSTAbits.SPEN = 1;
    TXSTAbits.TXEN = 1;
}

void uart_write(char *data) {
    while (*data != '\0') {
        while (!PIR1bits.TXIF);
        TXREG = *data++;
    }
}

void log_status(void) {
    uart_write("Logging status\r\n");
}
