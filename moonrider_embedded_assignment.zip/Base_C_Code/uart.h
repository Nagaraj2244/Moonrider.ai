
#ifndef UART_H
#define UART_H

void init_uart(void);
void uart_write(char *data);
void log_status(void);

#endif
