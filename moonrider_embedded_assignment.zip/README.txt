Moonrider Indicator Module
===========================

- Target MCU: PIC18F4580
- Tools: MPLAB X IDE, XC8 Compiler, MATLAB Simulink
- This project contains:
    - Base C drivers (GPIO, UART, Timer)
    - Simulink model placeholder
    - UART Log

Integration Steps:
1. Import C code into MPLAB project.
2. Build Simulink FSM and generate embedded C code.
3. Merge Simulink application code with base drivers.
4. Flash and test on evaluation board.
